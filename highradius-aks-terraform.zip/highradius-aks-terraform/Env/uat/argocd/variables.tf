variable "subscription_id" { type = string }
variable "aks_cluster_name" { type = string }
variable "aks_resource_group_name" { type = string }
variable "chart_repository" { type = string }
variable "chart_name" { type = string }
variable "chart_version" { type = string }
