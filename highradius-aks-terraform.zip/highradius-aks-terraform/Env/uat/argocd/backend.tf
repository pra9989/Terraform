resource_group_name = ""
storage_account_name = ""
container_name = "tfstate"
key = "uat-argocd.tfstate"
use_azuread_auth = true
