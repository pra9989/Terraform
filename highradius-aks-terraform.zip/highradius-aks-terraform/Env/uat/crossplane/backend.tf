resource_group_name = """
storage_account_name = ""
container_name = "tfstate"
key = "uat-crossplane.tfstate"
use_azuread_auth = true
