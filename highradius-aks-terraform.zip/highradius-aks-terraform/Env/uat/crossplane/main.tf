module "crossplane" {
  source = "../../../modules/crossplane"
  chart_repository = var.chart_repository
  chart_name = var.chart_name
  chart_version = var.chart_version
}
