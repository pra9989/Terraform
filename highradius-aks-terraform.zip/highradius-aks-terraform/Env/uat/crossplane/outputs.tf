output "release_name" { value = module.crossplane.release_name }
output "namespace" { value = module.crossplane.namespace }
output "status" { value = module.crossplane.status }
