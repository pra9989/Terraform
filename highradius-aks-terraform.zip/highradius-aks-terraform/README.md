# HighRadius — Create NEW AKS cluster, then install Crossplane and Argo CD (UAT / PROD)

This package is specifically for **creating a new private AKS cluster** in an existing resource group, VNet and subnet, then installing one Crossplane and one Argo CD instance. It is NOT an import of the previously deployed `core-turtle8-aks-cluster`. Use a **new, unique cluster name** in each environment. The AKS root owns the new cluster and its state.

## Folder layout

- `modules/network`: read-only lookups for existing VNet/subnet
- `modules/aks`: new private AKS resource, existing user-assigned control-plane identity, system node pool
- `modules/crossplane`: Helm release
- `modules/argocd`: Helm release
- `live/uat/{aks,crossplane,argocd}`: three separate Terraform roots/states
- `live/prod/{aks,crossplane,argocd}`: three separate Terraform roots/states

## Prerequisites (not created by this package)

- Approved existing AKS resource group, VNet, dedicated subnet, user-assigned managed identity, and required Network Contributor assignment on the VNet/subnet; optionally set `create_aks_network_role_assignment=true` if the Terraform identity is authorized to assign Azure roles.
- Correct private AKS DNS and egress to required Azure endpoints and chart/image registries.
- Entra-based Kubernetes deployment identity with AKS Cluster User and Kubernetes RBAC permissions; VDI/runner network access to the **private** API endpoint.
- Approved Helm charts reachable from the runner. The public Crossplane chart URL returned HTTP 403 in the earlier POC; change to a reachable approved mirror if necessary.
- Separate Azure Storage backend/state for UAT/PROD and each stage for operational deployments. Backend example files are provided; the storage account/container must be created separately.

## Step 1 — Create a NEW AKS cluster (UAT example)

From `live/uat/aks`, copy `terraform.tfvars.example` to `terraform.tfvars` and set the actual subscription, RG, existing VNet/subnet, existing identity, **NEW cluster name**, approved VM size, version, network CIDRs and egress. `terraform.tfvars.example` intentionally uses a placeholder cluster name so you do not accidentally target the existing cluster.

```powershell
terraform init
terraform fmt
terraform validate
terraform plan -out=aks.tfplan
terraform apply aks.tfplan
```

The AKS module provisions a new private cluster with one system node pool, Entra RBAC, local accounts disabled, OIDC/workload identity, Azure CNI Overlay/Cilium. It does **not** create a new VNet or modify the pre-existing network Terraform state. If the existing AKS identity lacks networking permission, the deployment will fail until an administrator assigns it or Terraform is authorized to create the role assignment.

## Step 2 — Install Crossplane

From `live/uat/crossplane`, copy `terraform.tfvars.example` to `terraform.tfvars` and use the **same newly created** AKS cluster name/RG/subscription. Set approved chart repository/version. Run `terraform init`, `terraform plan -out=crossplane.tfplan`, `terraform apply crossplane.tfplan`.

## Step 3 — Install Argo CD

From `live/uat/argocd`, use the same cluster inputs, set approved chart version/repository and run `terraform init`, `terraform plan -out=argocd.tfplan`, `terraform apply argocd.tfplan`.

Repeat separately under `live/prod` for production, with independent state and production-specific values. Never run UAT and PROD roots against the same cluster name unless deliberately migrating state.

## Security and scope

- No manual `helm install`, `kubectl apply`, SSH, or user-profile kubeconfig path is required for installation.
- Terraform Helm provider uses `kubelogin` with `azurecli` in this VDI **testing** template. It uses the signed-in user's Azure identity, **not** the AKS managed identity. For production replace it with an approved federated CI/CD deployment identity.
- The AKS control-plane identity is the pre-existing user-assigned managed identity configured in `terraform.tfvars`.
- The chart modules install controllers only. They do **not** configure Crossplane Azure provider, federated provider identity, Argo CD Git repositories/applications, monitoring/backup/DR, or a complete HA baseline.
- The current AKS module intentionally retains the provided system pool configuration (`only_critical_addons_enabled=false`) so controllers can schedule without a separately provisioned user pool. Before production, review a dedicated autoscaling user node pool, system-pool taints, capacity, zone resilience, monitoring, and firewall egress.
- The deployment is **not fully unattended** until external identity, role assignments, DNS/network connectivity, chart registry and state backend prerequisites are provisioned.

## Common issue

If Helm reports `Kubernetes cluster unreachable: the server has asked for the client to provide credentials`, check Entra AKS authentication, the VDI's Azure CLI session, `kubelogin`, AKS Cluster User and Azure Kubernetes Service RBAC Cluster Admin assignments (or delegated scoped Kubernetes RBAC). Do not use AKS local admin certificates because this cluster disables local accounts.
