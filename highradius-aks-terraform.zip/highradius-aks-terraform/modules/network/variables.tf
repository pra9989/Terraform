variable "vnet_resource_group_name" { type = string }
variable "virtual_network_name" { type = string }
variable "aks_subnet_name" { type = string }
