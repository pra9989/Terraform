output "vnet_id" { value = data.azurerm_virtual_network.existing.id }
output "location" { value = data.azurerm_virtual_network.existing.location }
output "subnet_id" { value = data.azurerm_subnet.existing.id }
output "subnet_prefixes" { value = data.azurerm_subnet.existing.address_prefixes }
output "vnet_prefixes" { value = data.azurerm_virtual_network.existing.address_space }
output "route_table_id" { value = data.azurerm_subnet.existing.route_table_id }
