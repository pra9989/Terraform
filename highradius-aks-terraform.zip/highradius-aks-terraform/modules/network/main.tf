# Read-only: networking stays owned by the separate RG/subnet project.
data "azurerm_virtual_network" "existing" {
  name                = var.virtual_network_name
  resource_group_name = var.vnet_resource_group_name
}

data "azurerm_subnet" "existing" {
  name                 = var.aks_subnet_name
  virtual_network_name = data.azurerm_virtual_network.existing.name
  resource_group_name  = var.vnet_resource_group_name
}
