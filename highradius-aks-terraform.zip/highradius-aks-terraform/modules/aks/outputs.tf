output "cluster_name" { value = azurerm_kubernetes_cluster.this.name }
output "cluster_id" { value = azurerm_kubernetes_cluster.this.id }
output "oidc_issuer_url" { value = azurerm_kubernetes_cluster.this.oidc_issuer_url }
output "private_fqdn" { value = azurerm_kubernetes_cluster.this.private_fqdn }
output "node_resource_group" { value = azurerm_kubernetes_cluster.this.node_resource_group }
