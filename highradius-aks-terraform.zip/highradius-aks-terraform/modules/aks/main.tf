locals {
  # Compare each pod/service range at its common prefix with VNet/connected ranges.
  cidr_pairs = concat(
    [{ a = var.pod_cidr, b = var.service_cidr }],
    flatten([for cidr in concat(var.vnet_prefixes, var.connected_network_cidrs) : [
      { a = var.pod_cidr, b = cidr },
      { a = var.service_cidr, b = cidr }
    ]])
  )
  cidr_overlaps = [for pair in local.cidr_pairs :
    cidrhost("${cidrhost(pair.a, 0)}/${min(tonumber(split("/", pair.a)[1]), tonumber(split("/", pair.b)[1]))}", 0) ==
    cidrhost("${cidrhost(pair.b, 0)}/${min(tonumber(split("/", pair.a)[1]), tonumber(split("/", pair.b)[1]))}", 0)
  ]
}

resource "azurerm_kubernetes_cluster" "this" {
  name                = var.cluster_name
  location            = var.location
  resource_group_name = var.resource_group_name
  dns_prefix          = var.dns_prefix
  kubernetes_version  = var.kubernetes_version
  sku_tier            = "Standard"

  private_cluster_enabled             = true
  private_cluster_public_fqdn_enabled = false
  private_dns_zone_id                 = "System"
  role_based_access_control_enabled   = true
  local_account_disabled              = true
  oidc_issuer_enabled                 = true
  workload_identity_enabled           = true
  azure_policy_enabled                = true
  automatic_upgrade_channel           = "patch"
  node_os_upgrade_channel             = "NodeImage"

  azure_active_directory_role_based_access_control {
    tenant_id          = var.tenant_id
    azure_rbac_enabled = true
  }

  default_node_pool {
    name                         = "system"
    temporary_name_for_rotation  = "sysrotate"
    node_count                   = var.node_count
    vm_size                      = var.node_vm_size
    vnet_subnet_id               = var.subnet_id
    zones                        = length(var.availability_zones) == 0 ? null : var.availability_zones
    only_critical_addons_enabled = false
    node_public_ip_enabled       = false
    os_disk_size_gb              = 128
    os_disk_type                 = "Managed"
    os_sku                       = "Ubuntu"
    type                         = "VirtualMachineScaleSets"
    max_pods                     = 50
    node_labels                  = { purpose = "admin-system" }
    upgrade_settings {
      max_surge                     = "33%"
      drain_timeout_in_minutes      = 30
      node_soak_duration_in_minutes = 5
    }
    tags = var.tags
  }

  identity {
    type         = "UserAssigned"
    identity_ids = [var.control_plane_identity_id]
  }

  network_profile {
    network_plugin      = "azure"
    network_plugin_mode = "overlay"
    network_data_plane  = "cilium"
    network_policy      = "cilium"
    outbound_type       = var.outbound_type
    pod_cidr            = var.pod_cidr
    service_cidr        = var.service_cidr
    dns_service_ip      = var.dns_service_ip
    load_balancer_sku   = "standard"
  }

  /*oms_agent {
    log_analytics_workspace_id      = var.log_analytics_workspace_id
    msi_auth_for_monitoring_enabled = true
  }*/

  storage_profile {
    blob_driver_enabled         = false
    disk_driver_enabled         = true
    file_driver_enabled         = true
    snapshot_controller_enabled = true
  }

  lifecycle {
    precondition {
      condition     = !anytrue(local.cidr_overlaps)
      error_message = "Pod/service CIDRs must not overlap each other, the VNet, or supplied connected_network_cidrs."
    }
    precondition {
      condition     = cidrhost("${var.dns_service_ip}/${split("/", var.service_cidr)[1]}", 0) == cidrhost(var.service_cidr, 0) && var.dns_service_ip != cidrhost(var.service_cidr, 0) && var.dns_service_ip != cidrhost(var.service_cidr, 1) && var.dns_service_ip != cidrhost(var.service_cidr, -1)
      error_message = "dns_service_ip must be usable within service_cidr, excluding the first service IP."
    }
    precondition {
      condition     = var.outbound_type != "userDefinedRouting" || var.udr_egress_ready
      error_message = "Confirm approved firewall/NVA egress and DNS before setting udr_egress_ready=true."
    }
  }
  tags = var.tags
}
