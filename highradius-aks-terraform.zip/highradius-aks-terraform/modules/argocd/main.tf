resource "helm_release" "this" {
  name             = "argocd"
  namespace        = "argocd"
  create_namespace = true
  repository       = var.chart_repository
  chart            = var.chart_name
  version          = var.chart_version
  wait             = true
  atomic           = true
  cleanup_on_fail  = true
  timeout          = 1200
  values = [yamlencode({
    server = {
      replicas = var.server_replicas
      service = { type = "ClusterIP" }
    }
    repoServer = { replicas = var.repo_server_replicas }
    controller = { replicas = var.controller_replicas }
    configs = { params = { "server.insecure" = false } }
  })]
}
