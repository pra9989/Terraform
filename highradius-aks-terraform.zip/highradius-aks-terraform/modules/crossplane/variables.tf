variable "chart_repository" { type = string }
variable "chart_name" { type = string }
variable "chart_version" { type = string }
variable "replicas" { type = number
  default = 1 }
variable "image_tag" { type = string
  default = null }
