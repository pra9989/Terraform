resource "helm_release" "this" {
  name             = "crossplane"
  namespace        = "crossplane-system"
  create_namespace = true
  repository       = var.chart_repository
  chart            = var.chart_name
  version          = var.chart_version
  wait             = true
  atomic           = true
  cleanup_on_fail  = true
  timeout          = 1200
  values = [yamlencode({ replicas = var.replicas })]
  dynamic "set" {
    for_each = var.image_tag == null ? [] : [var.image_tag]
    content {
      name  = "image.tag"
      value = set.value
    }
  }
}
